# Httpd Installation with index.html

# Pre-requisites
    ec2 instance
# Install httpd using below command
    yum install httpd -y
# Copy index.html file to "/var/www/html"
# Start httpd service
    service httpd start
# Open port number 80 and check check output by using Instance IP address
  ![image](https://user-images.githubusercontent.com/58024415/107868269-fcd04200-6ea8-11eb-991b-5bb64447070d.png)
